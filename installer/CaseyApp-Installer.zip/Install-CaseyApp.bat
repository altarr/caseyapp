@echo off
echo Starting CaseyApp installer...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
echo -----------------------------------------------
echo Installer finished. Review output above.
echo -----------------------------------------------
pause
