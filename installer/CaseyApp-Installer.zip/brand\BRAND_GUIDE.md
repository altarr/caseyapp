# TrendAI Brand Guide

This repository contains all TrendAI brand assets, style definitions, and the QR code generator. Assets are organized into two categories:

- **`digital/`** — Assets and guidelines for web, web apps, digital media, screens, and presentations
- **`physical/`** — Assets and guidelines for print, merchandise, signage, and physical materials

For visual references and detailed examples, see the full brand guidelines PDF (`GUI00_TrendAI_Brand_Guidelines_260312US.pdf`) included in this directory.

---

## Repository Structure

```
brand/
├── digital/                        ← Web, apps, screens, digital media
│   ├── logos/
│   │   ├── horizontal/             PNG logos (Full Color, Black, White, Inverted)
│   │   ├── icon/                   PNG icons + favicon
│   │   ├── tagline/                SVG + PNG tagline lockups
│   │   └── wordmarks/              SVG co-brand wordmarks
│   ├── fonts/
│   │   ├── Inter/                  Product UI typeface
│   │   ├── WorkSans/               Body copy typeface
│   │   └── Aptos/                  Microsoft Office fallback
│   ├── gradients/                  PNG gradient previews
│   ├── imagery/
│   │   ├── stock/                  Stock photography (JPG)
│   │   └── icons/                  Icon sets
│   ├── templates/                  PPT backgrounds (AI)
│   └── qrcode.min.js              Branded QR code generator
│
├── physical/                       ← Print, merchandise, signage
│   ├── logos/
│   │   ├── eps/                    EPS vector logos for print
│   │   └── tagline/                EPS tagline lockup
│   ├── fonts/
│   │   ├── Gotham/                 Primary heading typeface (print)
│   │   └── MinionPro-Regular.otf   Supplementary print typeface
│   ├── gradients/                  AI source files for print production
│   ├── promotional/                Merchandise mockups (PNG/JPG)
│   └── templates/                  Roll-up banners (PDF, CMYK)
│
├── BRAND_GUIDE.md                  This file
└── GUI00_TrendAI_Brand_Guidelines_260312US.pdf
```

---

## Brand Overview & Messaging

### Brand Line

> **AI Fearlessly**

### Primary Message

> Lead the future of AI with proactive security designed to inspire innovation and eliminate risk.

### Core Messages

| Pillar | Message |
|--------|---------|
| **Built for AI. Ready for Next.** | We deliver security built for the AI age. From single project deployments to large agentic agendas, we allow you to reach your AI goals. |
| **Stay Ahead of AI-Powered Threats** | Our world-leading threat intelligence delivers real-time insight, predictive research, and risk visibility to help you act before threats become incidents. |
| **Adaptive Platform. Real Security Outcomes.** | TrendAI Vision One unifies security data, controls, and action into a single adaptive platform that secures every part of your environment. |
| **Proven Leadership That Puts Customers First** | With 35+ years defending the digital frontier, TrendAI pairs relentless customer defense with relentless customer support. |

### Tone of Voice

| Attribute | Guidance |
|-----------|----------|
| **Courageous** | Write with confidence. Use imperative and simple tenses ("lead the future," not "can lead the future"). |
| **Positive** | Focus on possibilities we enable, not the dangers we prevent. Be the company customers *want* to work with. |
| **Clear & Direct** | Use approachable language without sacrificing accuracy. If a sentence can be simpler, make it simpler. |
| **Outcome-focused** | Lead with outcomes, follow with technology. "Protect all facets of your enterprise" over "we have a comprehensive platform." |
| **Empathetic & Human** | Use second-person language. We "help you thrive," not "secure enterprises." |
| **Meaningfully Experienced** | Focus on what customers *get* from our 35+ years of experience, not just that we have it. |
| **Bold & Successful** | Write with pride rooted in reality. We're a global leader trusted across 185 countries. |

---

## Logo Assets

### Logo Construction
- The **brandmark** is called the "TrendAI Spark." The curve reflects global reach and trusted leadership; the spark represents intelligence, insight, and possibility. TrendAI Red anchors our purpose: passionate, urgent, and customer-first.
- The **wordmark** uses the **Onest** typeface with a custom "A" reflecting the curvature of the Spark and a smile.
- The primary logo should be used whenever possible.

### Digital Logos (`digital/logos/`)

For web, apps, screens, presentations, and digital media. All files are RGB color space.

#### Full Logo (Horizontal wordmark)
| File | Use | Background |
|------|-----|------------|
| `digital/logos/horizontal/TrendAI-Logo-Full-Color-RGB.png` | Primary logo | White/light backgrounds |
| `digital/logos/horizontal/TrendAI-Logo-Black-RGB.png` | Monochrome | White/light backgrounds |
| `digital/logos/horizontal/TrendAI-Logo-White-RGB.png` | Inverted | Dark/black backgrounds |
| `digital/logos/horizontal/TrendAI-Logo-Inverted-RGB.png` | Inverted with color icon | Dark backgrounds |
| `digital/logos/tagline/TrendAI-Tagline-Vertical-Inverse-RGB.png` | Logo with tagline (vertical) | Dark backgrounds |

#### Icon Only — TrendAI Spark (Brandmark)
| File | Use | Background |
|------|-----|------------|
| `digital/logos/icon/TrendAI-Logo-Icon-Full-Color-RGB.png` | Primary icon | White/light backgrounds |
| `digital/logos/icon/TrendAI-Logo-Icon-Black-RGB.png` | Monochrome icon | White/light backgrounds |
| `digital/logos/icon/TrendAI-Logo-Icon-White-RGB.png` | Inverted icon | Dark/black backgrounds |

#### Favicon
| File | Size | Use |
|------|------|-----|
| `digital/logos/icon/favicon.png` | 64x64 | Browser tab icon, app icon |

**Favicon generation**: The favicon is the full-color icon resized to 64x64 with `contain` fit (transparent padding, no cropping). To regenerate:
```javascript
const sharp = require('sharp');
sharp('digital/logos/icon/TrendAI-Logo-Icon-Full-Color-RGB.png')
  .resize(64, 64, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
  .toFile('digital/logos/icon/favicon.png');
```

#### SVG / Scalable Assets
| File | Use |
|------|-----|
| `digital/logos/tagline/TrendAI-Tagline-Horizontal-Full-Color-RGB.svg` | Scalable tagline lockup |
| `digital/logos/wordmarks/TrendAI_Initiative_Wordmarks_RGB_*.svg` | Initiative co-brand wordmarks |
| `digital/logos/wordmarks/TrendAI_Partners_Wordmarks_RGB_*.svg` | Partner co-brand wordmarks |

#### Digital Logo Sizing
| Variant | Min Height |
|---------|-----------|
| Primary horizontal logo | 20px |
| Vertical / stacked logo | 50px |
| Standalone Spark (brandmark) | 18px |
| Logo with tagline | 27px |

### Physical / Print Logos (`physical/logos/`)

For print production, merchandise, signage, and any output sent to a printer or manufacturer. All EPS files are vector and can be scaled without quality loss.

| File | Use |
|------|-----|
| `physical/logos/eps/TrendAI-Logo-Full-Color-RGB.eps` | Full color logo for print |
| `physical/logos/eps/TrendAI-Logo-Inverted-RGB.eps` | Inverted logo for dark print substrates |
| `physical/logos/tagline/TrendAI-Tagline-Vertical-Full-Color-RGB.eps` | Tagline lockup for print |

#### Print Logo Sizing
| Variant | Min Height |
|---------|-----------|
| Primary horizontal logo | 0.275 in |
| Vertical / stacked logo | 0.375 in |
| Standalone Spark (brandmark) | 0.25 in |
| Logo with tagline | 0.375 in |

#### Print Color Notes
- For **CMYK printing**, convert PMS values using the Pantone Bridge guide
- For **apparel and merchandise**, use **PMS 186** instead of PMS 485 (TrendAI Red) to prevent orange shift after washing
- Confirm Pantone colors with your printer before production

### Logo Rules (All Media)

#### Clear Space
Maintain a clear zone around the logo equal to **half the height of the logo or brandmark**. No other elements should intrude into this space.

#### Background Usage
- **Dark backgrounds** (black, #0a0a0a, #111): Use the White or Inverted variants
- **Light backgrounds** (white, #fff, #e5e5e5): Use the Full Color or Black variants
- **Gradient backgrounds**: Use the White logo variant
- **Red backgrounds**: Use the all-White logo variant

#### Tagline Usage
- The tagline "AI Fearlessly" should only appear with the primary horizontal logo
- **Never** use the tagline logo as the website/app logo (the tagline would be too small to read)

#### Partner Cobrand
- Use a combined logo unit: TrendAI primary logo + partner logo separated by a vertical line
- Partner logo height should match the TrendAI brandmark height
- If the partner logo exceeds the TrendAI logo width, set it to that width and center vertically
- Obtain permissions from both TrendAI and the partner before creating a cobrand lockup

#### Logo Misuse — Do Not:
- Stretch, distort, or change the aspect ratio
- Rotate the logo
- Use colors not specified for the logo
- Add bevel, emboss, or 3D effects
- Add an outline stroke to the logo
- Apply gradient fill to the logo
- Place the logo in a holding shape (circle, square, etc.)
- Lock up additional text to the logo
- Add a drop shadow
- Rearrange elements of the logo
- Use multiply or other blend modes
- Change the relationship between the logo components (wordmark and Spark)
- Place the logo over busy images where legibility is compromised

---

## Brand Elements — The TrendAI Spark

The TrendAI Spark is the standalone brandmark and a core expression of the visual identity. It can function as a focal hero element or a subtle supporting graphic device.

### Allowed Treatments
| Treatment | Description |
|-----------|-------------|
| **Solid fill** | Standard solid color rendering |
| **Gradient** | Gradient treatment using brand gradients |
| **Line / stroke** | Refined stroke rendering for a lighter, minimal look |
| **Masking device** | Reveals a sharp portion of an image while blurring the area beyond |
| **Pattern** | Repeated to create dynamic patterns adding rhythm and texture |

### Rules
- At least **two points** of the Spark must always remain visible within a composition (unless used as a repeating pattern)
- The Spark must **not** be used as a tiled or wallpaper-style background
- The full TrendAI logo must appear **nearby** whenever the Spark is used alone
- **Multi-page exception**: In multi-page documents, the Spark may appear without the logo on subsequent pages, provided the full logo and Spark appear together on the first page

---

## Color Palette

### Primary Colors
| Name | Hex | RGB | PMS | Use |
|------|-----|-----|-----|-----|
| **TrendAI Red** | `#d71920` | 215, 25, 32 | PMS 485 C | Primary brand color, buttons, accents, links |
| **Amber** | `#ff9500` | 255, 149, 0 | PMS 2013 C | Secondary accent, gradient endpoint |
| **Signal** | `#2e0fe4` | 46, 15, 228 | PMS 2728 C | Secondary color, gradient accent |
| **Black** | `#000000` | 0, 0, 0 | Black 6 C | Core brand color, backgrounds |
| **White** | `#ffffff` | 255, 255, 255 | — | Primary color in light mode, text on dark/colored backgrounds |

### Digital-Specific Colors

These colors apply to web, app, and screen-based designs only.

#### Extended Colors (App-Specific)
| Name | Hex | RGB | Use |
|------|-----|-----|-----|
| **TrendAI Red Dark** | `#b81419` | 184, 20, 25 | Hover states, dark red accents *(not in core brand palette)* |

#### Dark Theme (Default for Digital)
| Name | Hex | Use |
|------|-----|-----|
| **Background** | `#000000` | Page background |
| **Card** | `#0a0a0a` | Card/panel backgrounds |
| **Input** | `#111111` | Form input backgrounds |
| **Border** | `#1a1a1a` | Card borders, dividers |
| **Input Border** | `#333333` | Input field borders |

#### Text Colors
| Name | Hex | Use |
|------|-----|-----|
| **Primary Text** | `#e5e5e5` | Headings, body text |
| **Secondary Text** | `#888888` | Labels, captions, muted text |
| **Muted Text** | `#666666` | Very subtle text |
| **Placeholder** | `#444444` | Input placeholder text |
| **Error** | `#ff6b6f` | Error messages |

#### Status Colors
| Name | Hex | Use |
|------|-----|-----|
| **Live/Active** | `#d71920` | Live indicators, active states |
| **Success/Online** | `#22c55e` (green-500) | Online indicators, success |
| **Warning** | `#ff9500` | Warnings, "must change password" |
| **Error** | `#ff6b6f` | Errors, delete buttons |

### Physical-Specific Color Notes

- **Pantone (PMS) values** are the authoritative reference for all print and physical production
- For **merchandise and apparel**, use **PMS 186** instead of PMS 485 for TrendAI Red — this produces a deeper red that resists orange shift after washing
- Always request a **press proof or color proof** before approving production runs
- CMYK conversions should be derived from the PMS values using the Pantone Bridge guide, not from RGB/Hex conversions
- **Spot color printing** (Pantone) is preferred over process color (CMYK) when budget allows, for maximum color accuracy

### Color Ratio Guidance
Primary applications leverage **dark mode**. Use dark mode for: page heroes, presentation covers, digital ads, social banners. Use light mode for: text-heavy content, interior pages, long-form web content.

When designing, follow one of these on-brand ratios:
- **Dark-dominant**: 60% black, 30% TrendAI Red, 10% white
- **Red-accent**: 70% black, 15% TrendAI Red, 15% white
- **Balanced**: 50% black, 30% TrendAI Red, 20% white

TrendAI Red must always be the prominent brand color. Secondary colors (Amber, Signal) should not dominate compositions.

---

## Gradient System

### Brand Gradients

| Name | Type | Definition | Use |
|------|------|------------|-----|
| **TrendAI Linear Gradient** | Linear | TrendAI Red → Amber | Primary buttons, CTAs, hero elements |
| **TrendAI Radial Gradient** | Radial | TrendAI Red → Amber | Background accents, circular elements |
| **Amber Freeform Gradient** | Freeform | Amber-based organic blend | Supporting backgrounds, texture |
| **Full Color Freeform Gradient** | Freeform | Multi-color organic blend | Feature highlights |
| **Spark Gradient** | Freeform | Amber + Signal on black | Core visual identity asset — flame-inspired, mirrors Spark curvature |

### Digital Gradient Assets (`digital/gradients/`)

- `TrendAI_SparkGradient_01.png` — Rasterized gradient preview for screen use

#### CSS Implementation (TrendAI Linear)
```css
background: linear-gradient(135deg, #d71920 0%, #ff9500 100%);
```

#### Gradient in Headlines
Apply a TrendAI Red → Amber gradient to key words or phrases in headlines for emphasis:
- **Direction**: Left-to-right or top-to-bottom only (never reversed)
- **Color stops**: TrendAI Red at the 40% mark, Amber at 100%
- Dark backgrounds only

### Physical Gradient Assets (`physical/gradients/`)

Editable Adobe Illustrator source files for print production:

| File | Description |
|------|-------------|
| `Gradient.ai` | Base gradient template |
| `TrendAI_SparkGradient-RGB.ai` | Spark gradient source |
| `trendai-gradient-01 through 04-full-color-rgb.ai` | Freeform gradient variants |

**Print gradient notes:**
- Convert to CMYK before sending to print — do not use RGB AI files directly for production
- Gradient banding can occur in large print areas; work with your printer to use high-resolution output and smooth blending
- For merchandise (screen printing, embroidery), solid colors are preferred over gradients unless color reproduction can be consistently controlled

### Gradient Misuse — Do Not:
- Stretch or distort gradients to emphasize a single hue
- Highlight unintended color blends by zooming or cropping
- Allow secondary colors to dominate over TrendAI Red
- Use simplified two-color transitions like Red-to-Signal or Signal-to-Amber
- Create "muddy" or dull effects by adjusting established gradients
- Create large areas of color outside the brand palette (orange, grey, purple)

> See the brand guidelines PDF (pages 35-37) for visual gradient examples and freeform setup guidance.

---

## Typography

### Typeface Hierarchy

| Typeface | Role | Source | Context |
|----------|------|--------|---------|
| **Gotham** (Bold) | Primary headings | Adobe Fonts (subscription) / OTF in `physical/fonts/` | Marketing, print, signage |
| **Work Sans** | Body copy | Google Fonts (free) / TTF in `digital/fonts/` | Web, apps, digital body text |
| **Inter** | Product UI | Google Fonts (free) / TTF in `digital/fonts/` | Dashboards, settings, data-heavy screens |
| **Aptos** | Office fallback | System font (Microsoft) / TTF in `digital/fonts/` | PowerPoint, Word, Outlook |

### Digital Typography

For web, apps, and screen-based designs.

#### Context-Specific Usage
| Context | Headings | Body |
|---------|----------|------|
| Marketing / Web | Gotham Bold (via Adobe Fonts) | Work Sans |
| Product login pages | Gotham Bold (via Adobe Fonts) | Work Sans |
| Product dashboards / settings | Inter | Inter |
| Microsoft Office materials | Aptos | Aptos |

#### Font Imports

**Gotham** — Available via [Adobe Fonts](https://fonts.adobe.com/) (requires subscription). If unavailable, fall back to Work Sans for headings.

**Work Sans** — Google Fonts:
```html
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
```

**Inter** — Google Fonts (for product UI):
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
```

#### CSS Font Stacks
```css
/* Headings (marketing/web) */
font-family: 'Gotham', 'Work Sans', ui-sans-serif, system-ui, -apple-system, sans-serif;

/* Body copy */
font-family: 'Work Sans', ui-sans-serif, system-ui, -apple-system, sans-serif;

/* Product UI (dashboards/settings) */
font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif;
```

#### Font Weights
| Weight | Name | Use |
|--------|------|-----|
| 400 | Regular | Body text |
| 500 | Medium | Subtle emphasis |
| 600 | Semibold | Card titles, usernames |
| 700 | Bold | Headings, buttons, labels |

#### Text Styles (Screen)
| Element | Font | Size | Weight | Spacing | Transform | Color |
|---------|------|------|--------|---------|-----------|-------|
| Page heading | Gotham | 18-20px | 700 | 0.06em | uppercase | #e5e5e5 |
| Section heading | Gotham | 14px | 700 | 0.06em | uppercase | #d71920 |
| Body text | Work Sans | 14px | 400 | normal | none | #e5e5e5 |
| Label | Work Sans | 11px | 700 | 0.08em | uppercase | #888888 |
| Button text | Work Sans | 13px | 700 | 0.06em | uppercase | #ffffff |
| Small/caption | Work Sans | 12px | 400 | normal | none | #888888 |
| Tiny/badge | Work Sans | 10px | 700 | 0.06em | uppercase | varies |

### Physical / Print Typography

For printed materials, signage, merchandise, and anything that will be physically produced.

#### Font Files
| File | Typeface | Use |
|------|----------|-----|
| `physical/fonts/Gotham/Gotham Bold.otf` | Gotham Bold | Primary headings on all print materials |
| `physical/fonts/MinionPro-Regular.otf` | Minion Pro | Supplementary serif for formal print contexts |

#### Print Type Guidelines
- **Gotham Bold** is the primary heading typeface for all printed materials — marketing collateral, signage, banners, and merchandise
- **Work Sans** may be used for body copy in printed materials if Gotham is used for headings
- For **large-format printing** (banners, signage), ensure minimum stroke widths are maintained — thin weights may not reproduce well at distance
- For **embroidery**, use bold weights only; fine details in lighter weights will be lost in stitching
- Minimum embroidery text height: **0.25 in** for legibility

---

## Typography Basics (All Media)

### Alignment
80% of content should be **left-aligned**. Center-align only for introductory lines, preface text, and campaign copy that serves as an anchor of importance. Never use justified or right-aligned text.

### Casing
- **Body copy**: Always sentence case. Avoid ALL CAPS for paragraphs or body text.
- **Title case**: Use for solution/service names, text in graphic elements, proper titles, and eyebrows. Capitalize first letter of words, except minor words like "the" or "and."
- **Headlines**: Sentence case or title case as appropriate; never ALL CAPS.

### Bolding
Use sparingly — only for important phrases or calls to action. Overuse disrupts visual hierarchy.

### Headlines
- Keep to **2-3 lines** maximum for comfortable reading
- Avoid single long lines or dangling single-word widows on a second line

### Print / Layout
- Avoid orphans and widows in typeset content
- Avoid very long or very short column widths
- Maintain reasonable gutter widths between columns

---

## ADA Compliance (Digital)

All digital color combinations must meet **WCAG 2.1 AA** accessibility standards for contrast.

### Key Restrictions
| Combination | Requirement |
|-------------|-------------|
| **TrendAI Red on black** (or black on red) | Only permitted at **14pt bold or larger**, or **18pt (24px) or larger** at regular weight |
| **White on black** | Passes AA at all sizes |
| **White on TrendAI Red** | Passes AA at all sizes |
| **White on Signal** | Passes AA at all sizes |
| **Black on white** | Passes AA at all sizes |
| **Black on Amber** | Passes AA at all sizes |

### Guidance
- Use only the approved color combinations above — do not create additional pairings without testing
- Test contrast ratios with a WCAG checker tool before shipping new color combinations
- For detailed visual examples of all approved and prohibited pairings, see the brand guidelines PDF (page 25)

---

## Imagery Guidelines

- **Prefer product interface screenshots** and branded graphics over stock photography
- When stock is needed (e.g., vertical-specific audiences), always avoid:
  - "Fear-based" images: ominous lighting, hooded hackers, dark server rooms
  - Cliche cybersecurity imagery: magnifying glass over code, shields, digital meshes/globes
  - Stuffy corporate environments: people in suits in boardrooms
- **People in imagery** should feel candid, fearless, and confident — innovators leading with purpose
- Subjects can represent both decision-making executives and technical users

### Digital Imagery (`digital/imagery/`)

- Stock photos are located in `digital/imagery/stock/`
- Icon sets are in `digital/imagery/icons/`
- Virtual backgrounds and web assets are in `digital/imagery/`
- For web use, optimize images for file size (WebP preferred, JPEG fallback)
- Maintain responsive image sizing with `srcset` or equivalent

---

## Physical Guidelines — Merchandise & Print

### Promotional Items (`physical/promotional/`)

Mockup files are provided for reference. These show approved logo placement and color treatment on common merchandise.

#### Color Rules
- All merchandise must use **primary brand colors: red, white, black, or gray** only
- Approved brand gradients are permitted if color reproduction can be consistently controlled
- **Do not** use Amber or Signal (blue) as the primary color of promotional items

#### Logo on Merchandise
- Minimum embroidery logo length: **3 inches**. If not achievable through embroidery, use screen printing or embroidered patches
- If the logo is very small or embroidered and the TM is not legible, it may be removed as a rare exception
- If the TrendAI Spark brandmark is used on an item, the full TrendAI logo must appear nearby (exception: hats)

#### Apparel Color
- For apparel, use **PMS 186** instead of PMS 485 (TrendAI Red) for a deeper red that resists orange shift after washing

#### For Exceptions
Contact brandsupport@trendmicro.com

### Print Templates (`physical/templates/`)

| File | Description |
|------|-------------|
| `TrendAI_RollUp_Banner_Round6_001.pdf` | Roll-up banner design |
| `TrendAI_RollUpBanner_SparkOutline_White_CMYK_001.pdf` | Roll-up banner (CMYK, white spark outline) |

**Print production notes:**
- Banner files use CMYK color space — do not convert to RGB
- Ensure bleed areas are maintained per your printer's specifications
- Request a color proof before final production

---

## Digital Guidelines — Component Styles

These styles apply to web and app interfaces only.

### Buttons

**Primary (Gradient — TrendAI Red to Amber)**
```css
.btn-gradient {
  background: linear-gradient(135deg, #d71920 0%, #ff9500 100%);
  color: #fff;
  border: none;
  border-radius: 10px;
  padding: 12px 24px;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  cursor: pointer;
  transition: opacity 0.15s, transform 0.15s;
}
.btn-gradient:hover { opacity: 0.9; transform: translateY(-1px); }
.btn-gradient:disabled { opacity: 0.5; cursor: not-allowed; }
```

**Outline**
```css
.btn-outline {
  background: transparent;
  color: #888;
  border: 1px solid #333;
  border-radius: 10px;
  padding: 10px 24px;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  cursor: pointer;
  transition: border-color 0.15s, color 0.15s;
}
.btn-outline:hover { border-color: #d71920; color: #e5e5e5; }
```

### Cards
```css
.card {
  background: #0a0a0a;
  border: 1px solid #1a1a1a;
  border-radius: 16px;
  padding: 28px 32px;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
}
```

### Inputs
```css
.input {
  width: 100%;
  background: #111;
  border: 1px solid #333;
  border-radius: 10px;
  padding: 12px 14px;
  font-size: 14px;
  color: #e5e5e5;
  outline: none;
  transition: border-color 0.15s;
}
.input::placeholder { color: #444; }
.input:focus { border-color: #d71920; }
```

### Labels
```css
.field-label {
  display: block;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: #888;
  margin-bottom: 8px;
}
```

### Modals
```css
/* Overlay */
background: rgba(0, 0, 0, 0.8);
backdrop-filter: blur(4px);

/* Modal card — use .card styles */
max-width: 500px;
```

### Spinner
```css
.spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 2px solid #333;
  border-top-color: #d71920;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
```

---

## Role Badge Colors (Digital)

| Role | Background | Text |
|------|-----------|------|
| Admin | `rgba(215,25,32,0.2)` | `#d71920` |
| Speaker | `rgba(34,197,94,0.2)` | `#4ade80` |
| Translator | `rgba(59,130,246,0.2)` | `#60a5fa` |
| Panelist | `rgba(168,85,247,0.2)` | `#c084fc` |

---

## QR Code Generator (Digital)

### Files
- `digital/qrcode.min.js` — QR code generation library (client-side, vanilla JS)

### TrendAI QR Code Styles

Three branded presets with TrendAI logo overlay:

```javascript
const QR_STYLES = {
  red:   { color: '#d71920', bg: '#ffffff', logo: 'digital/logos/icon/TrendAI-Logo-Icon-Full-Color-RGB.png', logoBg: '#ffffff' },
  black: { color: '#000000', bg: '#ffffff', logo: 'digital/logos/icon/TrendAI-Logo-Icon-Black-RGB.png',      logoBg: '#ffffff' },
  white: { color: '#ffffff', bg: '#1a1a1a', logo: 'digital/logos/icon/TrendAI-Logo-Icon-White-RGB.png',      logoBg: '#1a1a1a' },
};
```

### Usage — Vanilla JS (with qrcode.min.js)

```html
<script src="digital/qrcode.min.js"></script>
<script>
function loadImage(src) {
  return new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

async function renderTrendAIQR(canvas, url, size, styleName) {
  const style = QR_STYLES[styleName || 'red'];

  // Generate QR code
  const scratch = document.createElement('div');
  scratch.style.display = 'none';
  document.body.appendChild(scratch);
  new QRCode(scratch, {
    text: url,
    width: size,
    height: size,
    colorDark: style.color,
    colorLight: style.bg,
    correctLevel: QRCode.CorrectLevel.H
  });
  const offscreen = scratch.querySelector('canvas');
  document.body.removeChild(scratch);

  // Draw to target canvas
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = style.bg;
  ctx.fillRect(0, 0, size, size);
  ctx.drawImage(offscreen, 0, 0, size, size);

  // Overlay TrendAI logo in center
  const logo = await loadImage(style.logo);
  if (logo) {
    const logoArea = size * 0.22;
    const padding = logoArea * 0.18;
    const half = logoArea / 2 + padding;
    const cx = size / 2;
    const cy = size / 2;
    ctx.fillStyle = style.logoBg;
    ctx.fillRect(cx - half, cy - half, half * 2, half * 2);
    ctx.drawImage(logo, cx - logoArea / 2, cy - logoArea / 2, logoArea, logoArea);
  }
}

// Example:
// <canvas id="myQR"></canvas>
// renderTrendAIQR(document.getElementById('myQR'), 'https://example.com', 300, 'red');
</script>
```

### Usage — npm (Node.js / Next.js / React)

```bash
npm install qrcode
```

```javascript
import QRCode from 'qrcode';

async function renderTrendAIQR(canvas, url, size, styleName = 'red') {
  const style = QR_STYLES[styleName];

  const tempCanvas = document.createElement('canvas');
  await QRCode.toCanvas(tempCanvas, url, {
    width: size,
    margin: 2,
    color: { dark: style.color, light: style.bg },
    errorCorrectionLevel: 'H',
  });

  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = style.bg;
  ctx.fillRect(0, 0, size, size);
  ctx.drawImage(tempCanvas, 0, 0, size, size);

  // Logo overlay
  const logo = await loadImage(style.logo);
  if (logo) {
    const logoArea = size * 0.22;
    const padding = logoArea * 0.18;
    const half = logoArea / 2 + padding;
    const cx = size / 2;
    const cy = size / 2;
    ctx.fillStyle = style.logoBg;
    ctx.fillRect(cx - half, cy - half, half * 2, half * 2);
    ctx.drawImage(logo, cx - logoArea / 2, cy - logoArea / 2, logoArea, logoArea);
  }
}
```

### QR Code Best Practices
- Always use **error correction level H** (highest) — allows the center logo overlay without breaking scanability
- The logo area should be **~22% of the QR size** — larger may prevent scanning
- Always wrap QR codes in a white or light container when displaying on dark backgrounds
- Standard sizes: 300px for display, 120px for thumbnails, 500px for projection
- For download/print, generate at 500px+ and export as PNG

---

## Tailwind CSS Configuration (Digital)

If using Tailwind CSS, add these custom colors to your config:

```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        red: '#d71920',
        'red-dark': '#b81419',
        amber: '#ff9500',
        signal: '#2e0fe4',
        card: '#0a0a0a',
        'card-border': '#1a1a1a',
        'input-bg': '#111111',
        'input-border': '#333333',
        muted: '#888888',
        'muted-2': '#666666',
        placeholder: '#444444',
        error: '#ff6b6f',
      },
    },
  },
};
```

Or use CSS custom properties:

```css
:root {
  --background: #000000;
  --foreground: #e5e5e5;
  --card: #0a0a0a;
  --card-border: #1a1a1a;
  --input-bg: #111111;
  --input-border: #333333;
  --muted: #888888;
  --muted-2: #666666;
  --placeholder: #444444;
  --red: #d71920;
  --red-dark: #b81419;
  --amber: #ff9500;
  --signal: #2e0fe4;
  --error: #ff6b6f;
}
```

---

## Quick Start

### Digital Projects (Web / Apps)

1. Copy the `brand/digital/` folder into your project
2. Copy logo PNGs to your public/static directory
3. Set favicon: copy `digital/logos/icon/favicon.png` to your app's favicon location
4. Import fonts:
   - **Gotham**: Import via Adobe Fonts (subscription required). If unavailable, use Work Sans Bold for headings as a fallback.
   - **Work Sans**: Add the Google Fonts link to your HTML head (body copy)
   - **Inter**: Add the Google Fonts link if building product UI dashboards/settings
5. Apply the color palette, component styles, and Tailwind config from this guide
6. Review the **ADA Compliance** section before finalizing color pairings
7. For QR codes: include `digital/qrcode.min.js` or install `qrcode` via npm

### Physical Projects (Print / Merchandise)

1. Use logo files from `brand/physical/logos/eps/` — these are vector and scale without quality loss
2. Install **Gotham Bold** from `physical/fonts/Gotham/`
3. Use **PMS color values** (not Hex/RGB) as the source of truth for all print colors
4. For apparel, specify **PMS 186** for TrendAI Red (resists orange shift after washing)
5. Reference mockups in `physical/promotional/` for approved merchandise treatments
6. Use gradient AI source files from `physical/gradients/` — convert to CMYK before production
7. Request a color proof from your printer/manufacturer before approving final production
8. For exceptions or questions, contact brandsupport@trendmicro.com
